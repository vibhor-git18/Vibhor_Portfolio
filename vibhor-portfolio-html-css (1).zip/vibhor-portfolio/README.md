VIBHOR AGARWAL — PERSONAL PORTFOLIO
===================================

FILES
-----
- index.html          The content and structure of the website.
- style.css           Colours, spacing, responsive layout, effects and animation.
- vibhor-portrait.jpeg  Your original uploaded photo, used in the hero section.

OPEN THE WEBSITE IN VS CODE
---------------------------
1. Extract vibhor-portfolio.zip to a folder.
2. Open the extracted vibhor-portfolio folder in Visual Studio Code.
3. If Live Server is not installed, open Extensions in VS Code, search for
   "Live Server", and install it.
4. In the Explorer panel, right-click index.html and choose "Open with Live Server".
5. Your browser will open the site. Save your edits and Live Server will refresh it.

You can also double-click index.html to open it in a browser. Live Server is
recommended while editing.

IMPORTANT HTML CONCEPTS
-----------------------
- <header> contains the top navigation.
- <nav> groups navigation links.
- <main> contains the main page sections.
- <section> divides the page into topics such as About, Skills and Contact.
- <article> groups a self-contained card, such as a skill or demo.
- <a href="#about"> jumps to the element with id="about".
- <img src="vibhor-portrait.jpeg"> displays the photo stored beside index.html.
  Keep the image file in the same folder so the path continues to work.

IMPORTANT CSS CONCEPTS
----------------------
- CSS variables in :root (for example --bg and --cyan) keep the theme consistent.
- Flexbox aligns items in a row or column.
- Flexbox (`display: flex`) arranges the Amazon-inspired navbar items in a row. CSS Grid is used elsewhere only where it helps organise responsive page sections.
- @media rules change the layout for smaller screens, including the mini navbar demo.
- :hover applies styles when a pointer is over a card.
- transition makes changes such as movement and border colour feel smooth.
- @keyframes spin defines the loader's rotation; animation repeats it.
- object-fit: cover makes the photo fill its frame without stretching.

NO JAVASCRIPT REQUIRED
---------------------
This portfolio uses only HTML and CSS. The navigation links wrap on small screens,
and the loader, hover card, and Amazon-inspired search bar are styled with CSS.
The search box is a visual practice demo and does not perform real product searches.

CUSTOMISING THE WEBSITE
----------------------
- Change wording in index.html.
- Change colours and spacing in style.css.
- Keep your photo named vibhor-portrait.jpeg, or update the img src in index.html
  if you rename it.
- Replace the learning-project text only when you have real projects to show.
- GitHub and email are linked in Contact. No LinkedIn link is included.

This site uses plain HTML and CSS only. It does not need a framework, JavaScript,
or a build step.
